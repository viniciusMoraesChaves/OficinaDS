const orcamentosRepository = require('../repositories/orcamentosRepository');
const clientesRepository = require('../repositories/clientesRepository');
const funcionariosRepository = require('../repositories/funcionariosRepository');
const cobrancasRepository = require('../repositories/cobrancasRepository');
const { parseId } = require('../utils/queryParams');
const { validarDecisao } = require('../utils/statusOrcamento');
const {
  validarUrgencia,
  normalizarFiltroUrgencia,
  validarOrdenacaoUrgencia
} = require('../utils/urgencia');
const { PERFIS } = require('../utils/perfis');
const { PRAZO_PAGAMENTO_DIAS } = require('../utils/inadimplencias');

async function criarAtendimento(req, res) {
  const idCliente = Number(req.body.idCliente);
  const idVeiculo = Number(req.body.idVeiculo);
  const idFuncionario = Number(req.body.idFuncionario);
  const urgencia = validarUrgencia(req.body.urgencia);

  if (!Number.isInteger(idCliente) || idCliente <= 0) {
    return res.status(400).json({ mensagem: 'Cliente inválido.' });
  }

  if (!Number.isInteger(idVeiculo) || idVeiculo <= 0) {
    return res.status(400).json({ mensagem: 'Veículo inválido.' });
  }
  if (!Number.isInteger(idFuncionario) || idFuncionario <= 0) {
    return res.status(400).json({ mensagem: 'Selecione o profissional responsável.' });
  }

  const cliente = await clientesRepository.findById(idCliente);

  if (!cliente) {
    return res.status(404).json({ mensagem: 'Cliente não encontrado.' });
  }

  const pertence = await orcamentosRepository.veiculoPertenceAoCliente(
    idVeiculo,
    idCliente
  );

  if (!pertence) {
    return res.status(400).json({
      mensagem: 'Este veículo não pertence ao cliente informado.'
    });
  }

  const funcionario = await funcionariosRepository.findAtivoById(idFuncionario);
  if (!funcionario) {
    return res.status(404).json({ mensagem: 'Profissional não encontrado ou inativo.' });
  }

  const atendimento = await orcamentosRepository.criarAtendimento({
    idCliente,
    idVeiculo,
    idFuncionario: funcionario.id,
    urgencia
  });

  res.status(201).json({ dados: atendimento });
}

async function listarAtendimentos(req, res) {
  const urgencia = normalizarFiltroUrgencia(req.query.urgencia);
  const ordenacao = validarOrdenacaoUrgencia(req.query.ordenacao);

  const atendimentos = await orcamentosRepository.listarAtendimentosAbertos({
    urgencia,
    ordenacao
  });

  res.json({ dados: atendimentos });
}

async function atualizarUrgencia(req, res) {
  const idAtendimento = parseId(req.params.id);
  const urgencia = validarUrgencia(req.body.urgencia, '');

  const atendimento = await orcamentosRepository.buscarAtendimentoPorId(
    idAtendimento
  );

  if (!atendimento) {
    return res.status(404).json({
      mensagem: 'Atendimento não encontrado.'
    });
  }

  const atualizado = await orcamentosRepository.atualizarUrgencia(
    idAtendimento,
    urgencia
  );

  if (!atualizado) {
    return res.status(409).json({
      mensagem: 'Somente atendimentos abertos podem ser alterados.'
    });
  }

  res.json({
    mensagem: 'Urgência atualizada.',
    dados: { id: idAtendimento, urgencia }
  });
}

async function listarMeusAtendimentos(req, res) {
  const cliente = await clientesRepository.findByUsuarioId(
    req.usuarioLogado.id
  );

  if (!cliente) {
    return res.json({ dados: [] });
  }

  const atendimentos = await orcamentosRepository.listarAtendimentosPorCliente(
    cliente.id
  );

  res.json({ dados: atendimentos });
}

async function removerAtendimento(req, res) {
  const idAtendimento = parseId(req.params.id);

  const atendimento = await orcamentosRepository.buscarAtendimentoPorId(
    idAtendimento
  );

  if (!atendimento) {
    return res.status(404).json({
      mensagem: 'Atendimento não encontrado.'
    });
  }

  const cancelado = await orcamentosRepository.cancelarAtendimento(
    idAtendimento
  );

  if (!cancelado) {
    return res.status(409).json({
      mensagem: 'Este atendimento já foi encerrado.'
    });
  }

  res.json({ mensagem: 'Cliente removido do atendimento.' });
}

async function criarOrcamento(req, res) {
  const idAtendimento = parseId(req.params.id);
  const { situacaoVeiculo, itens } = req.body;

  if (
    !situacaoVeiculo ||
    typeof situacaoVeiculo !== 'string' ||
    !situacaoVeiculo.trim()
  ) {
    return res.status(400).json({
      mensagem: 'Descreva a situação do veículo.'
    });
  }

  if (!Array.isArray(itens) || itens.length === 0) {
    return res.status(400).json({
      mensagem: 'Adicione ao menos um item de custo.'
    });
  }

  const itensValidados = [];

  for (const item of itens) {
    const descricao = String(item.descricao || '').trim();
    const valor = Number(item.valor);

    if (!descricao) {
      return res.status(400).json({
        mensagem: 'Todo item precisa de uma descrição.'
      });
    }

    if (!Number.isFinite(valor) || valor < 0) {
      return res.status(400).json({
        mensagem: 'Todo item precisa de um valor válido (maior ou igual a zero).'
      });
    }

    itensValidados.push({ descricao, valor });
  }

  const atendimento = await orcamentosRepository.buscarAtendimentoPorId(
    idAtendimento
  );

  if (!atendimento) {
    return res.status(404).json({
      mensagem: 'Atendimento não encontrado.'
    });
  }

  const orcamento = await orcamentosRepository.criarOrcamento({
    idAtendimento,
    situacaoVeiculo: situacaoVeiculo.trim(),
    itens: itensValidados
  });

  res.status(201).json({ dados: orcamento });
}

async function obterOrcamento(req, res) {
  const idOrcamento = parseId(req.params.id);

  const orcamento = await orcamentosRepository.buscarPorId(idOrcamento);

  if (!orcamento) {
    return res.status(404).json({
      mensagem: 'Orçamento não encontrado.'
    });
  }

  if (req.usuarioLogado.perfil === 'Cliente') {
    const cliente = await clientesRepository.findByUsuarioId(
      req.usuarioLogado.id
    );

    if (!cliente || cliente.id !== orcamento.idCliente) {
      return res.status(403).json({
        mensagem: 'Você não tem acesso a este orçamento.'
      });
    }
  }

  res.json({ dados: orcamento });
}

async function listarTodos(req, res) {
  const orcamentos = await orcamentosRepository.listarParaEquipe();

  res.json({ dados: orcamentos });
}

async function listarMeus(req, res) {
  const cliente = await clientesRepository.findByUsuarioId(
    req.usuarioLogado.id
  );

  if (!cliente) {
    return res.json({ dados: [] });
  }

  const orcamentos = await orcamentosRepository.listarPorCliente(cliente.id);

  res.json({ dados: orcamentos });
}

async function enviarOrcamento(req, res) {
  const idOrcamento = parseId(req.params.id);

  const enviado = await orcamentosRepository.marcarComoEnviado(idOrcamento);

  if (!enviado) {
    return res.status(409).json({
      mensagem: 'Este orçamento não pode ser enviado (já foi enviado ou não existe).'
    });
  }

  res.json({ mensagem: 'Orçamento enviado ao cliente.' });
}

// O orçamento aceito vira um valor a receber (Financeiro > Inadimplências).
// A decisão do cliente já está salva, então uma falha aqui não pode desfazê-la:
// o erro vai para o terminal e o script 24 recria a cobrança que faltar.
async function gerarCobranca(idOrcamento) {
  try {
    await cobrancasRepository.criarParaOrcamentoAceito(
      idOrcamento,
      PRAZO_PAGAMENTO_DIAS
    );
  } catch (error) {
    console.error(`Não foi possível gerar a cobrança do orçamento ${idOrcamento}.`, error);
  }
}

async function decidirOrcamento(req, res) {
  const idOrcamento = parseId(req.params.id);
  const decisao = String(req.body.decisao || '').trim().toLowerCase();

  const cliente = await clientesRepository.findByUsuarioId(
    req.usuarioLogado.id
  );

  const orcamento = await orcamentosRepository.buscarPorId(idOrcamento);

  if (!orcamento || !cliente || cliente.id !== orcamento.idCliente) {
    return res.status(404).json({
      mensagem: 'Orçamento não encontrado.'
    });
  }

  validarDecisao(orcamento, decisao);

  const atualizado = await orcamentosRepository.registrarDecisao(
    idOrcamento,
    decisao
  );

  if (!atualizado) {
    return res.status(409).json({
      mensagem: 'Este orçamento já teve uma decisão registrada.'
    });
  }

  if (decisao === 'aceito') {
    await gerarCobranca(idOrcamento);
  }

  res.json({
    mensagem: decisao === 'aceito'
      ? 'Orçamento aceito.'
      : 'Orçamento recusado.'
  });
}

async function atualizarStatusAtendimento(req, res) {
  const idAtendimento = parseId(req.params.id);
  const novoStatus = String(req.body.status || '').trim();
  const previsaoConclusao = req.body.previsaoConclusao ?? null;

  if (previsaoConclusao !== null) {
    const data = new Date(previsaoConclusao);

    if (
      typeof previsaoConclusao !== 'string' ||
      !previsaoConclusao.trim() ||
      Number.isNaN(data.getTime())
    ) {
      return res.status(400).json({
        mensagem: 'Previsão de conclusão inválida.'
      });
    }
  }

  const statusPermitidos = [
    'Aberta',
    'Em diagnóstico',
    'Em serviço',
    'Em testes',
    'Concluída'
  ];

  if (!statusPermitidos.includes(novoStatus)) {
    return res.status(400).json({
      mensagem: 'Status de atendimento inválido.'
    });
  }

  const administrador =
    req.usuarioLogado.perfil === PERFIS.ADMINISTRADOR;

  const funcionario = administrador
    ? null
    : await funcionariosRepository.findByUsuarioId(
        req.usuarioLogado.id
      );

  if (!administrador && !funcionario) {
    return res.status(403).json({
      mensagem: 'Funcionário não identificado.'
    });
  }

  const atualizado = await orcamentosRepository.atualizarStatusOrdem(
    idAtendimento,
    novoStatus,
    funcionario?.id ?? null,
    administrador,
    previsaoConclusao
  );

  if (!atualizado) {
    return res.status(404).json({
      mensagem: 'Atendimento não encontrado ou sem permissão para atualização.'
    });
  }

  res.json({ mensagem: 'Status atualizado com sucesso.' });
}

module.exports = {
  criarAtendimento,
  listarAtendimentos,
  atualizarUrgencia,
  listarMeusAtendimentos,
  removerAtendimento,
  criarOrcamento,
  obterOrcamento,
  listarMeus,
  listarTodos,
  enviarOrcamento,
  atualizarStatusAtendimento,
  decidirOrcamento
};
